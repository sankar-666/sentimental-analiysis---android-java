package com.example.text_sentiment_analysis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

public class EditPost extends AppCompatActivity implements JsonResponse {
    String post;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_post);

        EditText e1 = findViewById(R.id.editTextTextPersonName2);
        e1.setText(MyPost.posttxt);
        Button b1 = findViewById(R.id.button7);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                post = e1.getText().toString();

                JsonReq JR = new JsonReq();
                JR.json_response = (JsonResponse) EditPost.this;
                String q = "/editpost?post=" + post + "&post_id=" + MyPost.pid;
                q = q.replace(" ", "%20");
                JR.execute(q);

            }
        });

    }

    @Override
    public void response(JSONObject jo) {
        try {
            String status = jo.getString("status");
            Log.d("pearl", status);

            if (status.equalsIgnoreCase("success")) {

                Toast.makeText(getApplicationContext(),"Post Edited!",Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(),MyPost.class));



            }
        }
        catch (Exception e) {
            // TODO: handle exception

            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
        }
    }

    public void onBackPressed()
    {
        // TODO Auto-generated method stub
        super.onBackPressed();
        Intent b=new Intent(getApplicationContext(),MyPost.class);
        startActivity(b);
    }
}