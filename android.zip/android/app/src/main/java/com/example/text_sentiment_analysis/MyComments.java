package com.example.text_sentiment_analysis;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

public class MyComments extends AppCompatActivity implements JsonResponse {

    ListView l1;
    String comment;
    SharedPreferences sh;
    String [] uid,comnt,out,val;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_comments);


        sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());


        l1 =(ListView) findViewById(R.id.view);
        JsonReq JR = new JsonReq();
        JR.json_response = (JsonResponse) MyComments.this;
//        Toast.makeText(getApplicationContext(), UserHome.pid, Toast.LENGTH_LONG).show();
        String q = "/mypostcomment?pid=" +MyPost.pid;
        q = q.replace(" ", "%20");
        JR.execute(q);
    }

    @Override
    public void response(JSONObject jo) {
        try {



            String method = jo.getString("method");
            Log.d("result", method);
//                Toast.makeText(getApplicationContext(), status, Toast.LENGTH_LONG).show();

             if (method.equalsIgnoreCase("mypostcomment")) {
                String status = jo.getString("status");
                Log.d("result", status);
                Toast.makeText(getApplicationContext(), status, Toast.LENGTH_LONG).show();
                if (status.equalsIgnoreCase("success")) {

                    JSONArray ja = (JSONArray) jo.getJSONArray("data");


                    comnt = new String[ja.length()];
                    out= new String[ja.length()];
                    val = new String[ja.length()];


                    for (int i = 0; i < ja.length(); i++) {


                        comnt[i] = ja.getJSONObject(i).getString("comment");
                        out[i] = ja.getJSONObject(i).getString("emotion");


                        val[i] = "Comment: " + comnt[i]+"\nEmotion :" + out[i];
                    }
                    l1.setAdapter(new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, val));

                }
            }





        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
    }


    public void onBackPressed()
    {
        // TODO Auto-generated method stub
        super.onBackPressed();
        Intent b=new Intent(getApplicationContext(),MyPost.class);
        startActivity(b);
    }
}