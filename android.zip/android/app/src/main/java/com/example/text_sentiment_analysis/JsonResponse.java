package com.example.text_sentiment_analysis;

import org.json.JSONObject;

public interface JsonResponse {
	public void response(JSONObject jo);
}
