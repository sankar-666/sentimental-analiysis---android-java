package com.example.text_sentiment_analysis;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

public class ChatEmotion extends AppCompatActivity implements JsonResponse {

    TextView t1,t2;
    SharedPreferences sh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_emotion);

        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        String rid = sh.getString("receiver_id","");
        String sid = sh.getString("log_id","");


        JsonReq JR = new JsonReq();
        JR.json_response = (JsonResponse) ChatEmotion.this;
        String q = "/chatemotion?sid="+sid+"&rid="+rid;
        q = q.replace(" ", "%20");
        JR.execute(q);

        t1=findViewById(R.id.my);
        t2=findViewById(R.id.his);


    }

    @Override
    public void response(JSONObject jo) {

        try {

            String method = jo.getString("method");
            Log.d("pearl", method);

            if (method.equalsIgnoreCase("chatemotion")) {
                String status = jo.getString("status");
                if (status.equalsIgnoreCase("success")) {
//        Toast.makeText(getApplicationContext(), i1, Toast.LENGTH_SHORT).show();

                    String her = jo.getString("heremotion");
                    String my = jo.getString("myemotion");


                    t1.setText("Your Emotion: "+my);
                    t2.setText("Their Emotion: "+her);







                } else  if (status.equalsIgnoreCase("failed")) {
                    t1.setVisibility(View.INVISIBLE);
                    t2.setVisibility(View.INVISIBLE);
                    Toast.makeText(getApplicationContext(), "No messages yet!", Toast.LENGTH_SHORT).show();
                }
            }

        }
        catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
        }

    }
}