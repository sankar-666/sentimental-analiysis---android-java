package com.example.text_sentiment_analysis;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class UserHome extends AppCompatActivity implements JsonResponse, AdapterView.OnItemClickListener {

    ListView l1;
    String[] fname,lname,post,path,date,sts,value,post_id;
    public static String pid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);

        ImageButton i2 = findViewById(R.id.settings);
        l1=findViewById(R.id.allposts);
        l1.setOnItemClickListener(this);

        JsonReq JR = new JsonReq();
        JR.json_response = (JsonResponse) UserHome.this;
        String q = "/viewallposts";
        q = q.replace(" ", "%20");
        JR.execute(q);

        i2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(),UserSettings.class));
            }
        });
    }

    @Override
    public void response(JSONObject jo) {
        try {

            String method = jo.getString("method");
            Log.d("pearl", method);

            if (method.equalsIgnoreCase("viewallposts")) {
                String status = jo.getString("status");
                if (status.equalsIgnoreCase("success")) {
//                    Toast.makeText(getApplicationContext(), "test", Toast.LENGTH_LONG).show();

                    JSONArray ja1 = (JSONArray) jo.getJSONArray("data");
                    fname = new String[ja1.length()];
                    lname = new String[ja1.length()];
                    post= new String[ja1.length()];
                    path= new String[ja1.length()];
                    date= new String[ja1.length()];
                    sts= new String[ja1.length()];
                    value = new String[ja1.length()];
                    post_id = new String[ja1.length()];



                    for (int i = 0; i < ja1.length(); i++) {
                        fname[i] = ja1.getJSONObject(i).getString("fname");
                        lname[i] = ja1.getJSONObject(i).getString("lname");
                        post[i] = ja1.getJSONObject(i).getString("post");
                        path[i] = ja1.getJSONObject(i).getString("path");
                        date[i] = ja1.getJSONObject(i).getString("date");
                        sts[i] = ja1.getJSONObject(i).getString("status");

                        post_id[i] = ja1.getJSONObject(i).getString("post_id");


//                        Toast.makeText(getApplicationContext(), name[i]+" "+num[i], Toast.LENGTH_LONG).show();


                        value[i] = "User : " + fname[i]+lname[i] + "\nPost : " + post[i] + "\nPath : " + path[i]+"\nDate : " + date[i] + "\nStatus : " + sts[i]+"\n";
                    }
//                    ArrayAdapter<String> ar = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, value);
//                    l1.setAdapter(ar);

                    Custimage a = new Custimage(this, fname, lname, post, path, date);
                    l1.setAdapter(a);
                } else  if (status.equalsIgnoreCase("failed")) {
                    Toast.makeText(getApplicationContext(), "No Post, found!", Toast.LENGTH_SHORT).show();
                }
            }

        }
        catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
        }
    }
    public void onBackPressed()
    {
        // TODO Auto-generated method stub
        super.onBackPressed();
        Intent b=new Intent(getApplicationContext(),UserHome.class);
        startActivity(b);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        pid=post_id[i];
        final CharSequence[] items = {"Comment","Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(UserHome.this);
        // builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {


                if (items[item].equals("Comment")) {

                    startActivity(new Intent(getApplicationContext(),AddComment.class));


                }

                else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }

            }

        });
        builder.show();
    }
}